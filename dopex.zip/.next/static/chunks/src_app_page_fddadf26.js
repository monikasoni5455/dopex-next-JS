(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_faa634c7._.js",
  "static/chunks/src_app_a4441275._.js"
],
    source: "dynamic"
});
