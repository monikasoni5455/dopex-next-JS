(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_ef2d66e1._.js",
  "static/chunks/src_app_e92e5909._.js",
  "static/chunks/node_modules_react-responsive-carousel_lib_styles_carousel_min_5075f2c6.css"
],
    source: "dynamic"
});
