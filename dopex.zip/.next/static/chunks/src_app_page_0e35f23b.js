(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_0766a282._.js",
  "static/chunks/src_app_e92e5909._.js"
],
    source: "dynamic"
});
