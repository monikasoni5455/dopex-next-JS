/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['developers.elementor.com', 'your-fallback-domain.com'],
    },

};

export default nextConfig;